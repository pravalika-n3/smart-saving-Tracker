
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-slate-950 border-b border-slate-800 sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 lg:px-8 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="bg-indigo-600 p-2 rounded-lg shadow-lg shadow-indigo-500/20">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">Smart Saving <span className="text-indigo-400">Tracker</span></h1>
        </div>
        <div className="hidden sm:flex items-center gap-4 text-sm font-medium text-slate-400">
          <span className="hover:text-indigo-400 cursor-pointer transition-colors">Dashboard</span>
          <span className="hover:text-indigo-400 cursor-pointer transition-colors">Analytics</span>
          <div className="h-4 w-[1px] bg-slate-800"></div>
          <button className="bg-white text-slate-950 px-4 py-2 rounded-lg font-bold hover:bg-slate-200 transition-colors">
            Account
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
