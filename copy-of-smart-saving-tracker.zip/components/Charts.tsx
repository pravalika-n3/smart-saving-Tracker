
import React, { useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { Transaction, TransactionType } from '../types';

interface ChartsProps {
  transactions: Transaction[];
}

const COLORS = ['#818cf8', '#34d399', '#f87171', '#fbbf24', '#a78bfa', '#22d3ee', '#f472b6', '#94a3b8'];

const Charts: React.FC<ChartsProps> = ({ transactions }) => {
  const expenseData = useMemo(() => {
    const expenses = transactions.filter(t => t.type === TransactionType.EXPENSE);
    const totalsByCategory = expenses.reduce((acc, curr) => {
      acc[curr.category] = (acc[curr.category] || 0) + curr.amount;
      return acc;
    }, {} as Record<string, number>);

    return Object.keys(totalsByCategory).map(name => ({
      name,
      value: totalsByCategory[name],
    })).sort((a, b) => b.value - a.value);
  }, [transactions]);

  if (expenseData.length === 0) {
    return (
      <div className="h-[250px] flex items-center justify-center text-slate-600 text-sm italic">
        Add expenses to see analysis
      </div>
    );
  }

  return (
    <div className="h-[250px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={expenseData}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={80}
            paddingAngle={5}
            stroke="none"
            dataKey="value"
          >
            {expenseData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip 
            contentStyle={{ 
              backgroundColor: '#0f172a', 
              borderRadius: '12px', 
              border: '1px solid #1e293b', 
              boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.5)',
              color: '#f1f5f9'
            }}
            itemStyle={{ color: '#f1f5f9' }}
            formatter={(value: number) => `$${value.toFixed(2)}`}
          />
          <Legend 
            verticalAlign="bottom" 
            align="center"
            wrapperStyle={{ paddingTop: '10px', fontSize: '11px', color: '#94a3b8' }}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export default Charts;
