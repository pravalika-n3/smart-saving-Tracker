
import React, { useState, useEffect } from 'react';
import { Transaction, SavingsTip } from '../types';
import { getSavingsTips } from '../services/gemini';

interface AISavingsTipsProps {
  transactions: Transaction[];
  savings: number;
}

const AISavingsTips: React.FC<AISavingsTipsProps> = ({ transactions, savings }) => {
  const [tips, setTips] = useState<SavingsTip[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchTips = async () => {
    setLoading(true);
    const result = await getSavingsTips(transactions, savings);
    setTips(result);
    setLoading(false);
  };

  useEffect(() => {
    if (transactions.length > 0) {
      fetchTips();
    } else {
        setTips([
            { title: "Start Tracking", advice: "Add your first transaction to get personalized AI insights." }
        ]);
    }
  }, [transactions.length === 0]); 

  return (
    <div className="flex-grow flex flex-col">
      <div className="flex-grow space-y-4">
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="animate-pulse flex space-x-4">
                <div className="rounded-full bg-slate-800 h-10 w-10"></div>
                <div className="flex-1 space-y-2 py-1">
                  <div className="h-2 bg-slate-800 rounded w-3/4"></div>
                  <div className="h-2 bg-slate-800 rounded"></div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          tips.map((tip, idx) => (
            <div key={idx} className="flex items-start gap-4 p-3 rounded-xl hover:bg-slate-800 transition-colors">
              <div className="bg-indigo-500/10 text-indigo-400 p-2 rounded-lg shrink-0 border border-indigo-500/20">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M11 3a1 1 0 10-2 0v1a1 1 0 102 0V3zM15.657 5.757a1 1 0 00-1.414-1.414l-.707.707a1 1 0 001.414 1.414l.707-.707zM18 10a1 1 0 01-1 1h-1a1 1 0 110-2h1a1 1 0 011 1zM5.05 6.464A1 1 0 106.464 5.05l-.707-.707a1 1 0 00-1.414 1.414l.707.707zM5 10a1 1 0 01-1 1H3a1 1 0 110-2h1a1 1 0 011 1zM8 16v-1h4v1a2 2 0 11-4 0zM12 14c.015-.34.208-.646.477-.859a4 4 0 10-4.954 0c.27.213.462.519.477.859h4z" />
                </svg>
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-100 leading-tight mb-1">{tip.title}</h4>
                <p className="text-xs text-slate-400 leading-relaxed">{tip.advice}</p>
              </div>
            </div>
          ))
        )}
      </div>
      
      <button 
        onClick={fetchTips}
        disabled={loading || transactions.length === 0}
        className="mt-6 w-full flex items-center justify-center gap-2 py-2 text-xs font-bold text-indigo-400 border border-indigo-500/30 rounded-lg hover:bg-indigo-500/10 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
      >
        <svg xmlns="http://www.w3.org/2000/svg" className={`h-3 w-3 ${loading ? 'animate-spin' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
        </svg>
        Refresh AI Tips
      </button>
    </div>
  );
};

export default AISavingsTips;
