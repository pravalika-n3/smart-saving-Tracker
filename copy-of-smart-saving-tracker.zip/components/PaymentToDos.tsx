
import React, { useState } from 'react';
import { PaymentTask } from '../types';

interface PaymentToDosProps {
  payments: PaymentTask[];
  onAdd: (payment: Omit<PaymentTask, 'id' | 'isPaid'>) => void;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}

const PaymentToDos: React.FC<PaymentToDosProps> = ({ payments, onAdd, onToggle, onDelete }) => {
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [showForm, setShowForm] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !amount || !dueDate) return;
    onAdd({ title, amount: parseFloat(amount), dueDate });
    setTitle('');
    setAmount('');
    setDueDate('');
    setShowForm(false);
  };

  return (
    <div className="bg-slate-900 p-6 rounded-2xl shadow-xl border border-slate-800">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-slate-100">Payment To-Dos</h3>
        <button 
          onClick={() => setShowForm(!showForm)}
          className="text-xs font-bold text-indigo-400 hover:text-indigo-300 transition-colors"
        >
          {showForm ? 'Cancel' : '+ Add Payment'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="mb-6 space-y-3 bg-slate-800/50 p-4 rounded-xl border border-slate-700/50">
          <input
            type="text"
            placeholder="Payment title (e.g. Electric Bill)"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
            required
          />
          <div className="grid grid-cols-2 gap-2">
            <input
              type="number"
              placeholder="Amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
              required
            />
            <input
              type="date"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
              required
            />
          </div>
          <button type="submit" className="w-full bg-indigo-600 text-white py-2 rounded-lg text-sm font-bold hover:bg-indigo-700 transition-colors">
            Schedule Payment
          </button>
        </form>
      )}

      <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1 custom-scrollbar">
        {payments.length === 0 ? (
          <p className="text-center text-slate-500 text-sm py-4 italic">No scheduled payments</p>
        ) : (
          payments.map(payment => (
            <div 
              key={payment.id}
              className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
                payment.isPaid 
                  ? 'bg-slate-900 border-slate-800 opacity-60' 
                  : 'bg-slate-800/50 border-slate-700/50 hover:border-slate-600'
              }`}
            >
              <button 
                onClick={() => onToggle(payment.id)}
                className={`w-5 h-5 rounded-md border flex items-center justify-center transition-colors ${
                  payment.isPaid 
                    ? 'bg-indigo-500 border-indigo-500' 
                    : 'bg-transparent border-slate-600'
                }`}
              >
                {payment.isPaid && (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                )}
              </button>
              <div className="flex-grow min-w-0">
                <div className="flex justify-between items-start">
                  <h4 className={`text-sm font-medium truncate ${payment.isPaid ? 'line-through text-slate-500' : 'text-slate-200'}`}>
                    {payment.title}
                  </h4>
                  <span className={`text-xs font-bold ${payment.isPaid ? 'text-slate-500' : 'text-rose-400'}`}>
                    ${payment.amount.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-center mt-1">
                  <span className="text-[10px] text-slate-500">
                    Due: {new Date(payment.dueDate).toLocaleDateString()}
                  </span>
                  <button 
                    onClick={() => onDelete(payment.id)}
                    className="text-slate-600 hover:text-rose-500 transition-colors"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default PaymentToDos;
