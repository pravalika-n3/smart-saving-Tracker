
import React from 'react';

interface DashboardProps {
  income: number;
  expenses: number;
  savings: number;
}

const Dashboard: React.FC<DashboardProps> = ({ income, expenses, savings }) => {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
      <div className="bg-slate-900 p-6 rounded-2xl shadow-xl border border-slate-800">
        <p className="text-slate-400 text-sm font-medium mb-1">Total Income</p>
        <h2 className="text-2xl font-bold text-emerald-400">{formatCurrency(income)}</h2>
        <div className="mt-2 text-xs text-emerald-500 font-medium flex items-center gap-1">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M12 7a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0V8.414l-4.293 4.293a1 1 0 01-1.414 0L8 10.414l-4.293 4.293a1 1 0 01-1.414-1.414l5-5a1 1 0 011.414 0L11 10.586 14.586 7H12z" clipRule="evenodd" />
          </svg>
          Money coming in
        </div>
      </div>
      
      <div className="bg-slate-900 p-6 rounded-2xl shadow-xl border border-slate-800">
        <p className="text-slate-400 text-sm font-medium mb-1">Total Expenses</p>
        <h2 className="text-2xl font-bold text-rose-400">{formatCurrency(expenses)}</h2>
        <div className="mt-2 text-xs text-rose-500 font-medium flex items-center gap-1">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M12 13a1 1 0 100 2h5a1 1 0 001-1V9a1 1 0 10-2 0v2.586l-4.293-4.293a1 1 0 00-1.414 0L8 9.586 3.707 5.293a1 1 0 00-1.414 1.414l5 5a1 1 0 001.414 0L11 9.414 14.586 13H12z" clipRule="evenodd" />
          </svg>
          Money spent
        </div>
      </div>

      <div className={`p-6 rounded-2xl shadow-xl border ${savings >= 0 ? 'bg-indigo-950/30 border-indigo-500/30' : 'bg-amber-950/30 border-amber-500/30'}`}>
        <p className="text-slate-400 text-sm font-medium mb-1">Net Savings</p>
        <h2 className={`text-2xl font-bold ${savings >= 0 ? 'text-indigo-400' : 'text-amber-400'}`}>
          {formatCurrency(savings)}
        </h2>
        <div className={`mt-2 text-xs font-medium flex items-center gap-1 ${savings >= 0 ? 'text-indigo-500' : 'text-amber-500'}`}>
          {savings >= 0 ? 'Building wealth' : 'Needs attention'}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
