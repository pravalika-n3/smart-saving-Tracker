
export enum TransactionType {
  INCOME = 'INCOME',
  EXPENSE = 'EXPENSE'
}

export enum Category {
  FOOD = 'Food & Dining',
  RENT = 'Rent & Housing',
  UTILITIES = 'Utilities',
  TRANSPORT = 'Transportation',
  ENTERTAINMENT = 'Entertainment',
  HEALTH = 'Health & Fitness',
  SHOPPING = 'Shopping',
  INCOME = 'Salary/Income',
  OTHERS = 'Others'
}

export interface Transaction {
  id: string;
  amount: number;
  category: Category;
  description: string;
  date: string;
  type: TransactionType;
}

export interface SavingsTip {
  title: string;
  advice: string;
}

export interface PaymentTask {
  id: string;
  title: string;
  amount: number;
  dueDate: string;
  isPaid: boolean;
}
