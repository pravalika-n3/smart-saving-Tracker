
import { GoogleGenAI, Type } from "@google/genai";
import { Transaction, SavingsTip } from "../types";

export async function getSavingsTips(transactions: Transaction[], savings: number): Promise<SavingsTip[]> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    Analyze these monthly transactions and provide exactly 3 actionable, specific, and professional savings tips.
    
    Financial Summary:
    - Total Transactions: ${transactions.length}
    - Current Net Savings: $${savings.toFixed(2)}
    
    Transactions Data:
    ${JSON.stringify(transactions.map(t => ({ 
      type: t.type, 
      amount: t.amount, 
      category: t.category, 
      desc: t.description 
    })))}
    
    If there are no transactions, provide general smart saving habits.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING, description: "A catchy headline for the tip." },
              advice: { type: Type.STRING, description: "Detailed actionable advice." },
            },
            required: ["title", "advice"],
          },
        },
      },
    });

    const text = response.text;
    if (!text) return [];
    return JSON.parse(text);
  } catch (error) {
    console.error("Gemini API Error:", error);
    return [
      { title: "Review Subscriptions", advice: "Check for recurring charges you no longer use." },
      { title: "50/30/20 Rule", advice: "Try allocating 50% to needs, 30% to wants, and 20% to savings." },
      { title: "Meal Prep", advice: "Eating out often accounts for the highest discretionary spending." }
    ];
  }
}
