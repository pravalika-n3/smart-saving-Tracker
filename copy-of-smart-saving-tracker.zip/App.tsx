
import React, { useState, useEffect, useMemo } from 'react';
import { Transaction, TransactionType, Category, PaymentTask } from './types';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import TransactionForm from './components/TransactionForm';
import TransactionList from './components/TransactionList';
import Charts from './components/Charts';
import AISavingsTips from './components/AISavingsTips';
import PaymentToDos from './components/PaymentToDos';

const App: React.FC = () => {
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('smart_saving_transactions');
    return saved ? JSON.parse(saved) : [];
  });

  const [payments, setPayments] = useState<PaymentTask[]>(() => {
    const saved = localStorage.getItem('smart_saving_payments');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('smart_saving_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('smart_saving_payments', JSON.stringify(payments));
  }, [payments]);

  const addTransaction = (transaction: Omit<Transaction, 'id'>) => {
    const newTransaction: Transaction = {
      ...transaction,
      id: Math.random().toString(36).substr(2, 9),
    };
    setTransactions(prev => [newTransaction, ...prev]);
  };

  const deleteTransaction = (id: string) => {
    setTransactions(prev => prev.filter(t => t.id !== id));
  };

  const addPaymentTask = (payment: Omit<PaymentTask, 'id' | 'isPaid'>) => {
    const newPayment: PaymentTask = {
      ...payment,
      id: Math.random().toString(36).substr(2, 9),
      isPaid: false,
    };
    setPayments(prev => [newPayment, ...prev]);
  };

  const togglePaymentTask = (id: string) => {
    setPayments(prev => prev.map(p => p.id === id ? { ...p, isPaid: !p.isPaid } : p));
  };

  const deletePaymentTask = (id: string) => {
    setPayments(prev => prev.filter(p => p.id !== id));
  };

  const totals = useMemo(() => {
    return transactions.reduce(
      (acc, curr) => {
        if (curr.type === TransactionType.INCOME) {
          acc.income += curr.amount;
        } else {
          acc.expenses += curr.amount;
        }
        return acc;
      },
      { income: 0, expenses: 0 }
    );
  }, [transactions]);

  const savings = totals.income - totals.expenses;

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-200">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column: Stats and Charts */}
          <div className="lg:col-span-2 space-y-8">
            <Dashboard 
              income={totals.income} 
              expenses={totals.expenses} 
              savings={savings} 
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-slate-900 p-6 rounded-2xl shadow-xl border border-slate-800">
                <h3 className="text-lg font-semibold text-slate-100 mb-4">Expense Analysis</h3>
                <Charts transactions={transactions} />
              </div>
              <div className="bg-slate-900 p-6 rounded-2xl shadow-xl border border-slate-800 flex flex-col">
                <h3 className="text-lg font-semibold text-slate-100 mb-4">AI Smart Tips</h3>
                <AISavingsTips transactions={transactions} savings={savings} />
              </div>
            </div>

            <div className="bg-slate-900 p-6 rounded-2xl shadow-xl border border-slate-800">
              <h3 className="text-lg font-semibold text-slate-100 mb-4">Recent Transactions</h3>
              <TransactionList transactions={transactions} onDelete={deleteTransaction} />
            </div>
          </div>

          {/* Right Column: Form and Payments */}
          <div className="lg:col-span-1 space-y-8">
            <div className="sticky top-8 space-y-8">
              <TransactionForm onAdd={addTransaction} />
              <PaymentToDos 
                payments={payments} 
                onAdd={addPaymentTask} 
                onToggle={togglePaymentTask} 
                onDelete={deletePaymentTask} 
              />
            </div>
          </div>
          
        </div>
      </main>
      <footer className="py-6 text-center text-slate-500 text-sm border-t border-slate-900 bg-slate-950">
        &copy; {new Date().getFullYear()} Smart Saving Tracker. Empowering your financial future.
      </footer>
    </div>
  );
};

export default App;
